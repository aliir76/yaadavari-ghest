package com.example.yaadavari_ghest_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
