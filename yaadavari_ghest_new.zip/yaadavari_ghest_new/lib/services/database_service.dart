import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/installment.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'installments.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE installments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        startDate INTEGER NOT NULL,
        endDate INTEGER NOT NULL,
        dayOfMonth INTEGER NOT NULL,
        reminderDaysBefore INTEGER NOT NULL DEFAULT 3,
        isActive INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE installment_payments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        installmentId INTEGER NOT NULL,
        dueDate INTEGER NOT NULL,
        paidDate INTEGER,
        isPaid INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (installmentId) REFERENCES installments (id) ON DELETE CASCADE
      )
    ''');
  }

  // Installment CRUD operations
  Future<int> insertInstallment(Installment installment) async {
    final db = await database;
    int installmentId = await db.insert('installments', installment.toMap());
    
    // Generate payment schedule
    await _generatePaymentSchedule(installmentId, installment);
    
    return installmentId;
  }

  Future<List<Installment>> getAllInstallments() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('installments');
    
    List<Installment> installments = [];
    for (var map in maps) {
      final payments = await getPaymentsForInstallment(map['id']);
      installments.add(Installment.fromMap(map).copyWith(payments: payments));
    }
    
    return installments;
  }

  Future<Installment?> getInstallment(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'installments',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      final payments = await getPaymentsForInstallment(id);
      return Installment.fromMap(maps.first).copyWith(payments: payments);
    }
    return null;
  }

  Future<int> updateInstallment(Installment installment) async {
    final db = await database;
    return await db.update(
      'installments',
      installment.toMap(),
      where: 'id = ?',
      whereArgs: [installment.id],
    );
  }

  Future<int> deleteInstallment(int id) async {
    final db = await database;
    return await db.delete(
      'installments',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Payment operations
  Future<List<InstallmentPayment>> getPaymentsForInstallment(int installmentId) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'installment_payments',
      where: 'installmentId = ?',
      whereArgs: [installmentId],
      orderBy: 'dueDate ASC',
    );

    return List.generate(maps.length, (i) {
      return InstallmentPayment.fromMap(maps[i]);
    });
  }

  Future<int> updatePayment(InstallmentPayment payment) async {
    final db = await database;
    return await db.update(
      'installment_payments',
      payment.toMap(),
      where: 'id = ?',
      whereArgs: [payment.id],
    );
  }

  Future<List<InstallmentPayment>> getUpcomingPayments(int daysAhead) async {
    final db = await database;
    final now = DateTime.now();
    final futureDate = now.add(Duration(days: daysAhead));
    
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT p.*, i.title as installmentTitle, i.amount, i.reminderDaysBefore
      FROM installment_payments p
      JOIN installments i ON p.installmentId = i.id
      WHERE p.isPaid = 0 
      AND p.dueDate >= ? 
      AND p.dueDate <= ?
      AND i.isActive = 1
      ORDER BY p.dueDate ASC
    ''', [now.millisecondsSinceEpoch, futureDate.millisecondsSinceEpoch]);

    return List.generate(maps.length, (i) {
      return InstallmentPayment.fromMap(maps[i]);
    });
  }

  Future<List<InstallmentPayment>> getOverduePayments() async {
    final db = await database;
    final now = DateTime.now();
    
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT p.*, i.title as installmentTitle, i.amount
      FROM installment_payments p
      JOIN installments i ON p.installmentId = i.id
      WHERE p.isPaid = 0 
      AND p.dueDate < ?
      AND i.isActive = 1
      ORDER BY p.dueDate ASC
    ''', [now.millisecondsSinceEpoch]);

    return List.generate(maps.length, (i) {
      return InstallmentPayment.fromMap(maps[i]);
    });
  }

  Future<void> _generatePaymentSchedule(int installmentId, Installment installment) async {
    final db = await database;
    
    DateTime currentDate = DateTime(
      installment.startDate.year,
      installment.startDate.month,
      installment.dayOfMonth,
    );
    
    // If the day has already passed this month, start from next month
    if (currentDate.isBefore(installment.startDate)) {
      currentDate = DateTime(
        installment.startDate.year,
        installment.startDate.month + 1,
        installment.dayOfMonth,
      );
    }

    while (currentDate.isBefore(installment.endDate) || 
           currentDate.isAtSameMomentAs(installment.endDate)) {
      final payment = InstallmentPayment(
        installmentId: installmentId,
        dueDate: currentDate,
      );
      
      await db.insert('installment_payments', payment.toMap());
      
      // Move to next month
      if (currentDate.month == 12) {
        currentDate = DateTime(currentDate.year + 1, 1, installment.dayOfMonth);
      } else {
        currentDate = DateTime(currentDate.year, currentDate.month + 1, installment.dayOfMonth);
      }
    }
  }

  Future<double> getTotalInstallmentAmount() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(amount) as total
      FROM installments
      WHERE isActive = 1
    ''');
    
    return result.first['total'] as double? ?? 0.0;
  }

  Future<double> getTotalPaidAmount() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(i.amount) as total
      FROM installment_payments p
      JOIN installments i ON p.installmentId = i.id
      WHERE p.isPaid = 1 AND i.isActive = 1
    ''');
    
    return result.first['total'] as double? ?? 0.0;
  }

  Future<double> getTotalRemainingAmount() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(i.amount) as total
      FROM installment_payments p
      JOIN installments i ON p.installmentId = i.id
      WHERE p.isPaid = 0 AND i.isActive = 1
    ''');
    
    return result.first['total'] as double? ?? 0.0;
  }
} 