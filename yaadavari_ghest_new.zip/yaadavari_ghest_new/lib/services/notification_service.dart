import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:workmanager/workmanager.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import '../models/installment.dart';
import 'database_service.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    // Request permissions
    await _requestPermissions();

    // Initialize notifications
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Initialize background work
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
    await AndroidAlarmManager.initialize();
  }

  Future<void> _requestPermissions() async {
    await Permission.notification.request();
    await Permission.scheduleExactAlarm.request();
    await Permission.ignoreBatteryOptimizations.request();
  }

  void _onNotificationTapped(NotificationResponse response) {
    // Handle notification tap
    print('Notification tapped: ${response.payload}');
  }

  Future<void> showInstantNotification({
    required String title,
    required String body,
    String? payload,
  }) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'installment_reminder',
      'یادآوری اقساط',
      channelDescription: 'یادآوری موعد پرداخت اقساط',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
    );

    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await _flutterLocalNotificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      platformChannelSpecifics,
      payload: payload,
    );
  }

  Future<void> scheduleInstallmentReminders() async {
    final dbService = DatabaseService();
    final installments = await dbService.getAllInstallments();

    for (final installment in installments) {
      if (!installment.isActive) continue;

      for (final payment in installment.payments) {
        if (payment.isPaid) continue;

        final reminderDate = payment.dueDate.subtract(
          Duration(days: installment.reminderDaysBefore),
        );

        if (reminderDate.isAfter(DateTime.now())) {
          await _scheduleNotification(
            id: payment.id ?? 0,
            title: 'یادآوری پرداخت قسط',
            body: '${installment.reminderDaysBefore} روز دیگر موعد پرداخت قسط ${installment.title} فرا می‌رسد',
            scheduledDate: reminderDate,
            payload: 'installment_${installment.id}',
          );
        }

        // Schedule notification for due date
        if (payment.dueDate.isAfter(DateTime.now())) {
          await _scheduleNotification(
            id: (payment.id ?? 0) + 10000,
            title: 'موعد پرداخت قسط',
            body: 'امروز موعد پرداخت قسط ${installment.title} است - مبلغ: ${_formatCurrency(installment.amount)}',
            scheduledDate: payment.dueDate,
            payload: 'installment_${installment.id}',
          );
        }
      }
    }
  }

  Future<void> _scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
    String? payload,
  }) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'installment_reminder',
      'یادآوری اقساط',
      channelDescription: 'یادآوری موعد پرداخت اقساط',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
    );

    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await _flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      _convertToTZDateTime(scheduledDate),
      platformChannelSpecifics,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: payload,
    );
  }

  Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }

  Future<void> cancelNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }

  // Background task for checking overdue payments
  Future<void> scheduleBackgroundCheck() async {
    await Workmanager().registerPeriodicTask(
      'installment_check',
      'installmentCheck',
      frequency: const Duration(hours: 6),
      constraints: Constraints(
        networkType: NetworkType.not_required,
        requiresBatteryNotLow: false,
        requiresCharging: false,
        requiresDeviceIdle: false,
        requiresStorageNotLow: false,
      ),
    );
  }

  String _formatCurrency(double amount) {
    return '${amount.toStringAsFixed(0).replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]},',
    )} تومان';
  }

  dynamic _convertToTZDateTime(DateTime dateTime) {
    // For simplicity, we'll use the local timezone
    // In a real app, you might want to use timezone package
    return dateTime;
  }
}

// Background callback function
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    switch (task) {
      case 'installmentCheck':
        await _checkOverduePayments();
        break;
    }
    return Future.value(true);
  });
}

Future<void> _checkOverduePayments() async {
  final dbService = DatabaseService();
  final overduePayments = await dbService.getOverduePayments();
  final notificationService = NotificationService();

  for (final payment in overduePayments) {
    await notificationService.showInstantNotification(
      title: 'قسط معوقه',
      body: 'قسط شما معوقه شده است. لطفاً در اسرع وقت پرداخت کنید.',
      payload: 'overdue_${payment.installmentId}',
    );
  }
} 