import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/installment.dart';

class InstallmentCard extends StatelessWidget {
  final Installment installment;
  final Color color;
  final Function(InstallmentPayment) onPaymentPressed;
  final VoidCallback onDeletePressed;

  const InstallmentCard({
    super.key,
    required this.installment,
    required this.color,
    required this.onPaymentPressed,
    required this.onDeletePressed,
  });

  String _formatCurrency(double amount) {
    final formatter = NumberFormat('#,###');
    return '${formatter.format(amount)} تومان';
  }

  String _formatDate(DateTime date) {
    return DateFormat('yyyy/MM/dd').format(date);
  }

  InstallmentPayment? _getCurrentMonthPayment() {
    final now = DateTime.now();
    return installment.payments
        .where((p) => p.dueDate.month == now.month && p.dueDate.year == now.year)
        .firstOrNull;
  }

  String _getStatusText() {
    final now = DateTime.now();
    final currentPayment = _getCurrentMonthPayment();
    
    if (currentPayment == null) return 'بدون قسط این ماه';
    
    if (currentPayment.isPaid) {
      return 'پرداخت شده';
    }
    
    final daysUntilDue = currentPayment.dueDate.difference(now).inDays;
    
    if (daysUntilDue < 0) {
      return '${(-daysUntilDue)} روز معوقه';
    } else if (daysUntilDue == 0) {
      return 'امروز موعد پرداخت';
    } else if (daysUntilDue <= installment.reminderDaysBefore) {
      return '$daysUntilDue روز تا موعد پرداخت';
    } else {
      return 'موعد: ${_formatDate(currentPayment.dueDate)}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentPayment = _getCurrentMonthPayment();
    final canMarkAsPaid = currentPayment != null && !currentPayment.isPaid;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color,
            width: 2,
          ),
        ),
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          installment.title,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _formatCurrency(installment.amount),
                          style: TextStyle(
                            fontSize: 16,
                            color: color,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'delete') {
                        onDeletePressed();
                      }
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, color: Colors.red),
                            SizedBox(width: 8),
                            Text('حذف'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            // Content
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Status
                  Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: color,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _getStatusText(),
                          style: TextStyle(
                            fontSize: 14,
                            color: color,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 12),
                  
                  // Details
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'روز پرداخت: ${installment.dayOfMonth}',
                              style: const TextStyle(fontSize: 12),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'یادآوری: ${installment.reminderDaysBefore} روز قبل',
                              style: const TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'شروع: ${_formatDate(installment.startDate)}',
                              style: const TextStyle(fontSize: 12),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'پایان: ${_formatDate(installment.endDate)}',
                              style: const TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  
                  if (canMarkAsPaid) ...[
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () => onPaymentPressed(currentPayment!),
                        icon: const Icon(Icons.check),
                        label: const Text('این ماه پرداخت کردم'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
} 