import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/notification_service.dart';
import 'pin_setup_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final AuthService _authService = AuthService();
  final NotificationService _notificationService = NotificationService();

  bool _isAppLockEnabled = false;
  bool _isBiometricEnabled = false;
  bool _isBiometricAvailable = false;
  bool _hasPinSet = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final isAppLockEnabled = await _authService.isAppLockEnabled();
      final isBiometricEnabled = await _authService.isBiometricEnabled();
      final isBiometricAvailable = await _authService.isBiometricAvailable();
      final hasPinSet = await _authService.hasPinSet();

      setState(() {
        _isAppLockEnabled = isAppLockEnabled;
        _isBiometricEnabled = isBiometricEnabled;
        _isBiometricAvailable = isBiometricAvailable;
        _hasPinSet = hasPinSet;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _toggleAppLock(bool value) async {
    if (value && !_hasPinSet) {
      // Need to set up PIN first
      final result = await Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => const PinSetupScreen()),
      );
      
      if (result == true) {
        await _authService.setAppLockEnabled(true);
        _loadSettings();
      }
    } else {
      await _authService.setAppLockEnabled(value);
      setState(() {
        _isAppLockEnabled = value;
      });
    }
  }

  Future<void> _toggleBiometric(bool value) async {
    if (value) {
      final success = await _authService.authenticateWithBiometric();
      if (success) {
        await _authService.setBiometricEnabled(true);
        setState(() {
          _isBiometricEnabled = true;
        });
      }
    } else {
      await _authService.setBiometricEnabled(false);
      setState(() {
        _isBiometricEnabled = false;
      });
    }
  }

  Future<void> _changePin() async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const PinSetupScreen(isChanging: true)),
    );
    
    if (result == true) {
      _showSuccessSnackBar('رمز عبور با موفقیت تغییر کرد');
    }
  }

  Future<void> _removePin() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف رمز عبور'),
        content: const Text('آیا مطمئن هستید که می‌خواهید رمز عبور را حذف کنید؟ این کار قفل اپلیکیشن را نیز غیرفعال می‌کند.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('انصراف'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _authService.removePin();
      await _authService.setAppLockEnabled(false);
      await _authService.setBiometricEnabled(false);
      _loadSettings();
      _showSuccessSnackBar('رمز عبور حذف شد');
    }
  }

  Future<void> _scheduleNotifications() async {
    try {
      await _notificationService.scheduleInstallmentReminders();
      _showSuccessSnackBar('یادآوری‌ها برنامه‌ریزی شدند');
    } catch (e) {
      _showErrorSnackBar('خطا در برنامه‌ریزی یادآوری‌ها');
    }
  }

  Future<void> _cancelAllNotifications() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('لغو یادآوری‌ها'),
        content: const Text('آیا مطمئن هستید که می‌خواهید تمام یادآوری‌ها را لغو کنید؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('انصراف'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('لغو همه'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _notificationService.cancelAllNotifications();
      _showSuccessSnackBar('تمام یادآوری‌ها لغو شدند');
    }
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تنظیمات'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                // Security section
                const _SectionHeader(title: 'امنیت'),
                
                SwitchListTile(
                  title: const Text('قفل اپلیکیشن'),
                  subtitle: const Text('فعال‌سازی قفل با رمز عبور'),
                  value: _isAppLockEnabled,
                  onChanged: _toggleAppLock,
                  secondary: const Icon(Icons.lock),
                ),

                if (_isBiometricAvailable && _hasPinSet)
                  SwitchListTile(
                    title: const Text('احراز هویت بیومتریک'),
                    subtitle: const Text('استفاده از اثر انگشت یا تشخیص چهره'),
                    value: _isBiometricEnabled,
                    onChanged: _isAppLockEnabled ? _toggleBiometric : null,
                    secondary: const Icon(Icons.fingerprint),
                  ),

                if (_hasPinSet) ...[
                  ListTile(
                    title: const Text('تغییر رمز عبور'),
                    subtitle: const Text('تغییر رمز عبور فعلی'),
                    leading: const Icon(Icons.edit),
                    onTap: _changePin,
                    trailing: const Icon(Icons.arrow_forward_ios),
                  ),
                  
                  ListTile(
                    title: const Text('حذف رمز عبور'),
                    subtitle: const Text('حذف رمز عبور و غیرفعال‌سازی قفل'),
                    leading: const Icon(Icons.delete, color: Colors.red),
                    onTap: _removePin,
                    trailing: const Icon(Icons.arrow_forward_ios),
                  ),
                ],

                const Divider(),

                // Notifications section
                const _SectionHeader(title: 'یادآوری‌ها'),
                
                ListTile(
                  title: const Text('برنامه‌ریزی یادآوری‌ها'),
                  subtitle: const Text('برنامه‌ریزی مجدد تمام یادآوری‌ها'),
                  leading: const Icon(Icons.schedule),
                  onTap: _scheduleNotifications,
                  trailing: const Icon(Icons.arrow_forward_ios),
                ),
                
                ListTile(
                  title: const Text('لغو تمام یادآوری‌ها'),
                  subtitle: const Text('لغو تمام یادآوری‌های برنامه‌ریزی شده'),
                  leading: const Icon(Icons.notifications_off, color: Colors.red),
                  onTap: _cancelAllNotifications,
                  trailing: const Icon(Icons.arrow_forward_ios),
                ),

                const Divider(),

                // About section
                const _SectionHeader(title: 'درباره'),
                
                const ListTile(
                  title: Text('نسخه اپلیکیشن'),
                  subtitle: Text('1.0.0'),
                  leading: Icon(Icons.info),
                ),
                
                const ListTile(
                  title: Text('توسعه‌دهنده'),
                  subtitle: Text('Ali Falahi'),
                  leading: Icon(Icons.person),
                ),
                
                const ListTile(
                  title: Text('ایمیل'),
                  subtitle: Text('mnuali74@gmail.com'),
                  leading: Icon(Icons.email),
                ),
                
                const ListTile(
                  title: Text('شماره تماس'),
                  subtitle: Text('09128171974'),
                  leading: Icon(Icons.phone),
                ),
              ],
            ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;

  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).primaryColor,
        ),
      ),
    );
  }
} 