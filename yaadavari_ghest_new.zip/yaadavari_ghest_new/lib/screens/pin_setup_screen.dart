import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class PinSetupScreen extends StatefulWidget {
  final bool isChanging;

  const PinSetupScreen({super.key, this.isChanging = false});

  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  final AuthService _authService = AuthService();
  String _enteredPin = '';
  String _confirmPin = '';
  bool _isConfirming = false;
  bool _showError = false;
  String _errorMessage = '';

  void _onNumberPressed(String number) {
    if (_isConfirming) {
      if (_confirmPin.length < 4) {
        setState(() {
          _confirmPin += number;
          _showError = false;
        });

        if (_confirmPin.length == 4) {
          _verifyPins();
        }
      }
    } else {
      if (_enteredPin.length < 4) {
        setState(() {
          _enteredPin += number;
          _showError = false;
        });

        if (_enteredPin.length == 4) {
          setState(() {
            _isConfirming = true;
          });
        }
      }
    }
  }

  void _onDeletePressed() {
    if (_isConfirming) {
      if (_confirmPin.isNotEmpty) {
        setState(() {
          _confirmPin = _confirmPin.substring(0, _confirmPin.length - 1);
          _showError = false;
        });
      }
    } else {
      if (_enteredPin.isNotEmpty) {
        setState(() {
          _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
          _showError = false;
        });
      }
    }
  }

  void _verifyPins() {
    if (_enteredPin == _confirmPin) {
      _savePin();
    } else {
      setState(() {
        _showError = true;
        _errorMessage = 'رمزهای عبور مطابقت ندارند';
        _confirmPin = '';
      });
    }
  }

  Future<void> _savePin() async {
    try {
      if (widget.isChanging) {
        // Verify current PIN first
        final currentPinValid = await _authService.verifyPin(_enteredPin);
        if (!currentPinValid) {
          setState(() {
            _showError = true;
            _errorMessage = 'رمز عبور فعلی اشتباه است';
            _enteredPin = '';
            _confirmPin = '';
            _isConfirming = false;
          });
          return;
        }
      }

      await _authService.setPin(_enteredPin);
      
      if (mounted) {
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      setState(() {
        _showError = true;
        _errorMessage = 'خطا در ذخیره رمز عبور';
        _enteredPin = '';
        _confirmPin = '';
        _isConfirming = false;
      });
    }
  }

  void _resetPin() {
    setState(() {
      _enteredPin = '';
      _confirmPin = '';
      _isConfirming = false;
      _showError = false;
      _errorMessage = '';
    });
  }

  String _getTitle() {
    if (widget.isChanging) {
      return _isConfirming ? 'رمز عبور جدید را تأیید کنید' : 'رمز عبور جدید را وارد کنید';
    } else {
      return _isConfirming ? 'رمز عبور را تأیید کنید' : 'رمز عبور را تعین کنید';
    }
  }

  String _getSubtitle() {
    if (widget.isChanging) {
      return _isConfirming 
          ? 'رمز عبور جدید را مجدداً وارد کنید'
          : 'رمز عبور ۴ رقمی جدید انتخاب کنید';
    } else {
      return _isConfirming 
          ? 'رمز عبور را مجدداً وارد کنید'
          : 'رمز عبور ۴ رقمی انتخاب کنید';
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentPin = _isConfirming ? _confirmPin : _enteredPin;

    return Scaffold(
      backgroundColor: const Color(0xFF2196F3),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const Spacer(),
              
              // Logo and title
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(
                  Icons.lock_outline,
                  size: 40,
                  color: Color(0xFF2196F3),
                ),
              ),
              
              const SizedBox(height: 24),
              
              Text(
                _getTitle(),
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
              
              const SizedBox(height: 8),
              
              Text(
                _getSubtitle(),
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
                textAlign: TextAlign.center,
              ),
              
              const SizedBox(height: 48),
              
              // PIN dots
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (index) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: index < currentPin.length
                          ? Colors.white
                          : Colors.white.withOpacity(0.3),
                      border: Border.all(
                        color: _showError ? Colors.red : Colors.white,
                        width: 2,
                      ),
                    ),
                  );
                }),
              ),
              
              if (_showError) ...[
                const SizedBox(height: 16),
                Text(
                  _errorMessage,
                  style: const TextStyle(
                    color: Colors.red,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
              
              const SizedBox(height: 48),
              
              // Number pad
              Expanded(
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 1,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                  ),
                  itemCount: 12,
                  itemBuilder: (context, index) {
                    if (index == 9) {
                      // Reset button
                      return _buildActionButton(
                        icon: Icons.refresh,
                        onPressed: _resetPin,
                      );
                    } else if (index == 10) {
                      // Number 0
                      return _buildNumberButton('0');
                    } else if (index == 11) {
                      // Delete button
                      return _buildActionButton(
                        icon: Icons.backspace,
                        onPressed: _onDeletePressed,
                      );
                    } else {
                      // Numbers 1-9
                      return _buildNumberButton('${index + 1}');
                    }
                  },
                ),
              ),
              
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNumberButton(String number) {
    return GestureDetector(
      onTap: () => _onNumberPressed(number),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          shape: BoxShape.circle,
        ),
        child: Center(
          child: Text(
            number,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          shape: BoxShape.circle,
        ),
        child: Center(
          child: Icon(
            icon,
            size: 28,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
} 