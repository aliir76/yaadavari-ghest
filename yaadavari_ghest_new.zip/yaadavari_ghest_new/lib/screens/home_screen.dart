import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/installment.dart';
import '../services/database_service.dart';
import '../widgets/installment_card.dart';
import '../widgets/summary_card.dart';
import 'add_installment_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DatabaseService _databaseService = DatabaseService();
  List<Installment> _installments = [];
  bool _isLoading = true;
  double _totalAmount = 0;
  double _paidAmount = 0;
  double _remainingAmount = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final installments = await _databaseService.getAllInstallments();
      final totalAmount = await _databaseService.getTotalInstallmentAmount();
      final paidAmount = await _databaseService.getTotalPaidAmount();
      final remainingAmount = await _databaseService.getTotalRemainingAmount();

      setState(() {
        _installments = installments;
        _totalAmount = totalAmount;
        _paidAmount = paidAmount;
        _remainingAmount = remainingAmount;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorSnackBar('خطا در بارگذاری اطلاعات');
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
      ),
    );
  }

  Future<void> _markPaymentAsPaid(InstallmentPayment payment) async {
    try {
      final updatedPayment = payment.copyWith(
        isPaid: true,
        paidDate: DateTime.now(),
      );
      
      await _databaseService.updatePayment(updatedPayment);
      _showSuccessSnackBar('پرداخت با موفقیت ثبت شد');
      _loadData();
    } catch (e) {
      _showErrorSnackBar('خطا در ثبت پرداخت');
    }
  }

  Future<void> _deleteInstallment(Installment installment) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف قسط'),
        content: Text('آیا مطمئن هستید که می‌خواهید قسط "${installment.title}" را حذف کنید؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('انصراف'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await _databaseService.deleteInstallment(installment.id!);
        _showSuccessSnackBar('قسط با موفقیت حذف شد');
        _loadData();
      } catch (e) {
        _showErrorSnackBar('خطا در حذف قسط');
      }
    }
  }

  Color _getInstallmentColor(Installment installment) {
    final now = DateTime.now();
    final currentPayment = installment.payments
        .where((p) => !p.isPaid)
        .where((p) => p.dueDate.month == now.month && p.dueDate.year == now.year)
        .firstOrNull;

    if (currentPayment == null) return Colors.grey;

    final daysUntilDue = currentPayment.dueDate.difference(now).inDays;
    
    if (daysUntilDue < 0) {
      return Colors.red; // معوقه
    } else if (daysUntilDue <= installment.reminderDaysBefore) {
      return Colors.orange; // نزدیک به موعد
    } else {
      // Check if this month's payment is paid
      final thisMonthPayment = installment.payments
          .where((p) => p.dueDate.month == now.month && p.dueDate.year == now.year)
          .firstOrNull;
      
      if (thisMonthPayment?.isPaid == true) {
        return Colors.green; // پرداخت شده
      }
    }
    
    return Colors.blue; // عادی
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('یاداوری قسط'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: Column(
                children: [
                  // Summary cards
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: SummaryCard(
                            title: 'کل اقساط',
                            amount: _totalAmount,
                            color: Colors.blue,
                            icon: Icons.account_balance_wallet,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SummaryCard(
                            title: 'پرداخت شده',
                            amount: _paidAmount,
                            color: Colors.green,
                            icon: Icons.check_circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SummaryCard(
                            title: 'باقی مانده',
                            amount: _remainingAmount,
                            color: Colors.orange,
                            icon: Icons.pending,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Installments list
                  Expanded(
                    child: _installments.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.payment,
                                  size: 64,
                                  color: Colors.grey[400],
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'هیچ قسطی ثبت نشده است',
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'برای شروع، قسط جدید اضافه کنید',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[500],
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _installments.length,
                            itemBuilder: (context, index) {
                              final installment = _installments[index];
                              final color = _getInstallmentColor(installment);
                              
                              return InstallmentCard(
                                installment: installment,
                                color: color,
                                onPaymentPressed: (payment) => _markPaymentAsPaid(payment),
                                onDeletePressed: () => _deleteInstallment(installment),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => const AddInstallmentScreen()),
          );
          
          if (result == true) {
            _loadData();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
} 