class Installment {
  final int? id;
  final String title;
  final double amount;
  final DateTime startDate;
  final DateTime endDate;
  final int dayOfMonth; // روز ماه برای پرداخت
  final int reminderDaysBefore; // چند روز قبل یادآوری شود
  final bool isActive;
  final List<InstallmentPayment> payments;

  Installment({
    this.id,
    required this.title,
    required this.amount,
    required this.startDate,
    required this.endDate,
    required this.dayOfMonth,
    this.reminderDaysBefore = 3,
    this.isActive = true,
    this.payments = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'startDate': startDate.millisecondsSinceEpoch,
      'endDate': endDate.millisecondsSinceEpoch,
      'dayOfMonth': dayOfMonth,
      'reminderDaysBefore': reminderDaysBefore,
      'isActive': isActive ? 1 : 0,
    };
  }

  factory Installment.fromMap(Map<String, dynamic> map) {
    return Installment(
      id: map['id'],
      title: map['title'],
      amount: map['amount'].toDouble(),
      startDate: DateTime.fromMillisecondsSinceEpoch(map['startDate']),
      endDate: DateTime.fromMillisecondsSinceEpoch(map['endDate']),
      dayOfMonth: map['dayOfMonth'],
      reminderDaysBefore: map['reminderDaysBefore'],
      isActive: map['isActive'] == 1,
    );
  }

  Installment copyWith({
    int? id,
    String? title,
    double? amount,
    DateTime? startDate,
    DateTime? endDate,
    int? dayOfMonth,
    int? reminderDaysBefore,
    bool? isActive,
    List<InstallmentPayment>? payments,
  }) {
    return Installment(
      id: id ?? this.id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      dayOfMonth: dayOfMonth ?? this.dayOfMonth,
      reminderDaysBefore: reminderDaysBefore ?? this.reminderDaysBefore,
      isActive: isActive ?? this.isActive,
      payments: payments ?? this.payments,
    );
  }
}

class InstallmentPayment {
  final int? id;
  final int installmentId;
  final DateTime dueDate;
  final DateTime? paidDate;
  final bool isPaid;

  InstallmentPayment({
    this.id,
    required this.installmentId,
    required this.dueDate,
    this.paidDate,
    this.isPaid = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'installmentId': installmentId,
      'dueDate': dueDate.millisecondsSinceEpoch,
      'paidDate': paidDate?.millisecondsSinceEpoch,
      'isPaid': isPaid ? 1 : 0,
    };
  }

  factory InstallmentPayment.fromMap(Map<String, dynamic> map) {
    return InstallmentPayment(
      id: map['id'],
      installmentId: map['installmentId'],
      dueDate: DateTime.fromMillisecondsSinceEpoch(map['dueDate']),
      paidDate: map['paidDate'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['paidDate'])
          : null,
      isPaid: map['isPaid'] == 1,
    );
  }

  InstallmentPayment copyWith({
    int? id,
    int? installmentId,
    DateTime? dueDate,
    DateTime? paidDate,
    bool? isPaid,
  }) {
    return InstallmentPayment(
      id: id ?? this.id,
      installmentId: installmentId ?? this.installmentId,
      dueDate: dueDate ?? this.dueDate,
      paidDate: paidDate ?? this.paidDate,
      isPaid: isPaid ?? this.isPaid,
    );
  }
} 